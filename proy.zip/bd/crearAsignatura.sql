create table Asignatura (
codigo char(8) not null,
descripcion varchar(20) not null,
primary key (codigo)
);
