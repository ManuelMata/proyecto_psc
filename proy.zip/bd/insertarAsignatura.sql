insert into Asignatura (codigo,descripcion) values ("1","Programacion 1");
insert into Asignatura (codigo,descripcion) values ("2","Programacion 2");
insert into Asignatura (codigo,descripcion) values ("3","Programacion 3");
insert into Asignatura (codigo,descripcion) values ("4","Programacion 4");
insert into Asignatura (codigo,descripcion) values ("5","Programacion 5");
insert into Asignatura (codigo,descripcion) values ("6","Programacion 6");
insert into Asignatura (codigo,descripcion) values ("7","Programacion 7");
