insert into Persona (dni,nombre,apellidos) values ("20123456A","Juan","Perez Perez");
insert into Persona (dni,nombre,apellidos) values ("20123457B","Maria","Garcia");
insert into Persona (dni,nombre,apellidos) values ("20123458C","Jose","Perez");
insert into Persona (dni,nombre,apellidos) values ("20123459D","Jose","Ramirez");
