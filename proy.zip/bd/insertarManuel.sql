insert into Persona (dni,nombre,apellidos) values ("24333469K","Manuel","Mata Llorca");
