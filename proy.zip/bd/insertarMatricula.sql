insert into Matricula (dni,codigo) values ("24333469K","2");
